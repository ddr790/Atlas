# ATLAS — do pacote até a Play Store

## 0. Variáveis da IA (Dify/Udify)
O projeto usa as variáveis de ambiente `DIFY_API_URL` e `DIFY_API_KEY` no servidor Netlify. Elas ficam no arquivo `.env` para desenvolvimento/local. **Não mova a chave para `public/config.js` ou para o JavaScript do navegador.**

Para produção no Netlify, cadastre as mesmas variáveis em Site configuration > Environment variables. O arquivo `.env` incluído neste pacote contém uma chave fornecida pelo proprietário do projeto; evite publicar esse arquivo em repositórios públicos.


Tudo aqui é para você seguir na ordem. Não foi testado com as suas contas.

## 1. Firebase (login)
1. Em console.firebase.google.com crie um projeto.
2. Authentication > Método de login: ative **Google** e **E-mail/senha**. Mantenha Facebook desativado.
3. Configurações do projeto > Seus apps > adicione um app **Web** e copie o bloco de configuração.
4. Cole os valores em `public/config.js` (apiKey, authDomain, projectId, appId).

## 2. Hospedar no Netlify (com o servidor da chave)
1. Suba todos os arquivos desta pasta para um repositório no GitHub (site github.com > Add file > Upload files).
2. Em netlify.com: Add new site > Import from Git e escolha o repositório.
3. Em Site configuration > Environment variables crie:
   - `DIFY_API_URL` = URL da API do Dify (termina em /v1)
   - `DIFY_API_KEY` = chave do app no Dify (começa com app-)
   - `FIREBASE_PROJECT_ID` = ID do projeto Firebase (só entra quem estiver logado)
4. Faça o deploy. No Firebase, em Authentication > Settings > Authorized domains, adicione o endereço `xxx.netlify.app`.
5. Abra o endereço, entre e teste o chat.

## 3. Gerar o app Android
1. Abra pwabuilder.com, cole o endereço do site e toque em Package for stores > Android.
2. Escolha um ID de pacote (ex.: com.seunome.atlas), gere o **AAB** e **guarde o arquivo da chave de assinatura**: sem ele você não atualiza o app.
3. O PWABuilder entrega um `assetlinks.json`. Coloque em `public/.well-known/assetlinks.json` e faça novo deploy.
4. No Firebase, adicione o app Android (SHA-1 e SHA-256 da chave) se for usar login nativo no futuro.

## 4. Play Console
1. Crie a conta de desenvolvedor (taxa única) e o app.
2. Suba o AAB em **teste fechado**. Contas pessoais novas precisam de 12 testadores por 14 dias seguidos antes de pedir produção.
3. Preencha: política de privacidade (link público), segurança dos dados e a exclusão de conta (o app tem o botão "Excluir conta e dados"; informe também um link web).
4. O app deve mirar a API 36 ou superior; o PWABuilder já usa uma versão recente, confira ao gerar.

## Autenticação no Atlas
- O navegador usa Firebase Authentication com Google e E-mail/senha.
- A sessão é persistida pelo Firebase (`browserLocalPersistence`) e o estado da interface é sincronizado por `onAuthStateChanged`.
- O código diferencia Web de Capacitor: Web usa popup do Google; em Capacitor, o fluxo usa redirect como fallback. O pacote enviado, porém, **não contém uma pasta `android/` nem dependências nativas do Capacitor**, portanto a parte Android precisa ser integrada ao projeto nativo antes de poder ser validada como APK.
- Para Google nativo no Android, configure um plugin Firebase Authentication para Capacitor e cadastre SHA-1/SHA-256 do certificado usado no build; a documentação atual do plugin Capawesome exige a habilitação de `google.com` e os fingerprints Android.

## Limites conhecidos
- Sem ferramentas do Claude: com o Dify a IA não cria tarefas nem memórias sozinha.
- Ainda não há limite de mensagens por usuário. Defina limites no Dify para não estourar os créditos.
- O login por popup em app empacotado pode precisar de ajuste.
- A Google pode recusar apps que sejam só um site embrulhado; recursos de voz, câmera e lembretes ajudam.
