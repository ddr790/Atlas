import {createRemoteJWKSet,jwtVerify} from 'jose';
const JWKS=createRemoteJWKSet(new URL('https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com'));
export default async (req)=>{
  if(req.method!=='POST')return new Response('Método inválido',{status:405});
  const pid=process.env.FIREBASE_PROJECT_ID;let user='anon';
  if(pid){
    const tk=(req.headers.get('authorization')||'').replace('Bearer ','');
    try{const {payload}=await jwtVerify(tk,JWKS,{issuer:'https://securetoken.google.com/'+pid,audience:pid});user=payload.sub}
    catch{return new Response('Não autorizado',{status:401})}
  }
  const body=await req.json();
  const up=await fetch(process.env.DIFY_API_URL.replace(/\/$/,'')+'/chat-messages',{method:'POST',headers:{Authorization:'Bearer '+process.env.DIFY_API_KEY,'Content-Type':'application/json'},body:JSON.stringify({...body,user})});
  return new Response(up.body,{status:up.status,headers:{'Content-Type':up.headers.get('content-type')||'text/event-stream','Cache-Control':'no-store'}});
};
export const config={path:'/api/chat-messages'};
